"use strict";
var L_Endabgabe;
(function (L_Endabgabe) {
    /**
     * class for the arbitrator
     */
    class Referee extends L_Endabgabe.Movable {
        constructor(_position) {
            super(new L_Endabgabe.Vector(_position.X, _position.Y));
            // set default target
            this.target = new L_Endabgabe.Vector(_position.X, _position.Y);
            // set radius
            this.radius = 1.5 * L_Endabgabe.scale;
        }
        /**
         * draws arbitrator
         */
        draw() {
            L_Endabgabe.crc2.save();
            // draw player center
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.arc(this.position.X, this.position.Y, this.radius, 0, 2 * Math.PI, false);
            L_Endabgabe.crc2.fillStyle = this.color;
            L_Endabgabe.crc2.fill();
            L_Endabgabe.crc2.lineWidth = 1;
            L_Endabgabe.crc2.strokeStyle = "black";
            L_Endabgabe.crc2.stroke();
            L_Endabgabe.crc2.restore();
        }
    }
    L_Endabgabe.Referee = Referee;
})(L_Endabgabe || (L_Endabgabe = {}));
//# sourceMappingURL=referee.js.map