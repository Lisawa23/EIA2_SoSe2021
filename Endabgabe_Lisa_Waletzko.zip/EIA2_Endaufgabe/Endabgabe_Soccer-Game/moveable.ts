namespace L_Endabgabe {
    /**
     * super class to handle movable objects
     */
    export abstract class Movable {
        public position: Vector;
        public target: Vector;
        public radius: number;
        public speed: number; 
        public color: string;
        protected slowDown: boolean;
        protected speedLevel: number;
        
        constructor(_position: Vector) {
            this.position = _position;
            this.speed = 1;
            this.speedLevel = 1;
            this.slowDown = false;
            this.radius = 2 * scale;
        }
        /**
         * draws object
         */
        public abstract draw(): void;

        /**
         * moves object to target
         */
        public move(_target: Vector): void {
            // calc diff vector
            let diffVectr: Vector = new Vector(_target.X - this.position.X, _target.Y - this.position.Y);

            // calc length of diff vector and return if zero
            let vectorLength: number = Math.sqrt(Math.pow(diffVectr.X, 2) + Math.pow(diffVectr.Y, 2));
            if (vectorLength === 0) { 
                return; 
            }

            // calc speed by movable properties
            let speedLevel: number = this.speedLevel * (this.speed / 100);

            // apply slow down if activated (Ball)
            let speed: number = this.slowDown ? speedLevel * (vectorLength / 100) : speedLevel;

            // calc scaling
            let scaleFactor: number = speed / vectorLength;

            // apply scaling to diff
            diffVectr.scale(scaleFactor);

            // add diff to current pos
            this.position.add(diffVectr);
        }

    }

}