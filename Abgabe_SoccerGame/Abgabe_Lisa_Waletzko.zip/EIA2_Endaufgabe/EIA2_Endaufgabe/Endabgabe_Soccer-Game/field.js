"use strict";
var L_Endabgabe;
(function (L_Endabgabe) {
    /**
     * class to handlesoccer field
     */
    class SoccerField {
        constructor() {
            // padding of the field
            this.padding = 15 * L_Endabgabe.scale;
            // width of the field
            this.width = 105 * L_Endabgabe.scale;
            // height of the field
            this.height = 80 * L_Endabgabe.scale;
        }
        /**
         * whether the ball is in bounds or not
         */
        ballOut(_ball) {
            if (_ball.position.X < this.padding) {
                return true;
            }
            if (_ball.position.X > this.padding + this.width) {
                return true;
            }
            if (_ball.position.Y < this.padding) {
                return true;
            }
            if (_ball.position.Y > this.padding + this.height) {
                return true;
            }
            return false;
        }
        /**
         * draws soccer field
         */
        draw() {
            // default stuff
            L_Endabgabe.crc2.save();
            L_Endabgabe.crc2.fillStyle = "green";
            L_Endabgabe.crc2.fillRect(0, 0, L_Endabgabe.crc2.canvas.width, L_Endabgabe.crc2.canvas.height);
            // draw outline
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.moveTo(this.padding, this.padding);
            L_Endabgabe.crc2.lineTo(this.padding + this.width, this.padding);
            L_Endabgabe.crc2.lineTo(this.padding + this.width, this.padding + this.height);
            L_Endabgabe.crc2.lineTo(this.padding, this.padding + this.height);
            L_Endabgabe.crc2.lineTo(this.padding, this.padding);
            // mid line
            L_Endabgabe.crc2.moveTo(this.padding + (this.width / 2), this.padding);
            L_Endabgabe.crc2.lineTo(this.padding + (this.width / 2), this.padding + this.height);
            L_Endabgabe.crc2.lineWidth = 2;
            L_Endabgabe.crc2.strokeStyle = "#ffffff";
            L_Endabgabe.crc2.stroke();
            // goal area left
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.rect(this.padding, (this.padding + (this.height / 2)) - 50, 30, 100);
            L_Endabgabe.crc2.strokeStyle = "white";
            L_Endabgabe.crc2.stroke();
            // goal area right
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.rect(this.padding + this.width - 30, (this.padding + (this.height / 2)) - 50, 30, 100);
            L_Endabgabe.crc2.strokeStyle = "white";
            L_Endabgabe.crc2.stroke();
            // left goal
            L_Endabgabe.crc2.moveTo(this.padding, this.padding + (this.height / 2) - 20);
            L_Endabgabe.crc2.lineTo(this.padding - (5 * L_Endabgabe.scale), this.padding + (this.height / 2) - 20);
            L_Endabgabe.crc2.lineTo(this.padding - (5 * L_Endabgabe.scale), this.padding + (this.height / 2) + 20);
            L_Endabgabe.crc2.lineTo(this.padding, this.padding + (this.height / 2) + (40 / 2));
            L_Endabgabe.crc2.stroke();
            // right goal
            L_Endabgabe.crc2.moveTo(this.padding + this.width, this.padding + (this.height / 2) - 20);
            L_Endabgabe.crc2.lineTo(this.padding + this.width + (5 * L_Endabgabe.scale), this.padding + (this.height / 2) - 20);
            L_Endabgabe.crc2.lineTo(this.padding + this.width + (5 * L_Endabgabe.scale), this.padding + (this.height / 2) + 20);
            L_Endabgabe.crc2.lineTo(this.padding + this.width, this.padding + (this.height / 2) + 20);
            L_Endabgabe.crc2.stroke();
            // middle circle
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.arc(this.padding + (this.width / 2), this.padding + (this.height / 2), 50, 0, 2 * Math.PI, false);
            L_Endabgabe.crc2.lineWidth = 2;
            L_Endabgabe.crc2.strokeStyle = "white";
            L_Endabgabe.crc2.stroke();
            //dot
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.arc(this.padding + (this.width / 2), this.padding + (this.height / 2), 2, 0, 2 * Math.PI, false);
            L_Endabgabe.crc2.fillStyle = "white";
            L_Endabgabe.crc2.fill();
            L_Endabgabe.crc2.restore();
        }
        /**
     * whether the ball is in home goal or not
     */
        homeGoal(_ball) {
            if (_ball.position.X < this.padding &&
                _ball.position.Y > this.padding + (this.height / 2) - 20 &&
                _ball.position.Y < this.padding + (this.height / 2) + 20) {
                return true;
            }
            return false;
        }
        /**
         * whether the ball is in away goal or not
         */
        awayGoal(_ball) {
            if (_ball.position.X > this.padding + this.width &&
                _ball.position.Y > this.padding + (this.height / 2) - 20 &&
                _ball.position.Y < this.padding + (this.height / 2) + 20) {
                return true;
            }
            return false;
        }
    }
    L_Endabgabe.SoccerField = SoccerField;
})(L_Endabgabe || (L_Endabgabe = {}));
//# sourceMappingURL=field.js.map