"use strict";
var L_Endabgabe;
(function (L_Endabgabe) {
    /**
     * class to handle player
     */
    class Player extends L_Endabgabe.Movable {
        constructor(_position, _shotPower, _precision, _speed, _color, _team, _trikotNumer, _actionRadius) {
            super(new L_Endabgabe.Vector(_position.X, _position.Y));
            // speed 1 to 99
            this.speed = 80;
            // origin of the player
            this.origin = new L_Endabgabe.Vector(0, 0);
            // whether the player is highlighted or not
            this.highlighted = true;
            // default speed level which scales with speed
            this.speedLevel = 2;
            this.shotPower = _shotPower;
            this.precision = _precision;
            this.speed = _speed;
            this.color = _color;
            this.team = _team;
            this.active = true;
            this.tricotNumber = _trikotNumer;
            this.actionRadius = _actionRadius * L_Endabgabe.scale;
            this.origin = new L_Endabgabe.Vector(_position.X, _position.Y);
        }
        draw() {
            L_Endabgabe.crc2.save();
            // draw player center
            L_Endabgabe.crc2.beginPath();
            L_Endabgabe.crc2.arc(this.position.X, this.position.Y, this.highlighted ? this.radius * 1.5 : this.radius, 0, 2 * Math.PI, false);
            L_Endabgabe.crc2.fillStyle = this.color;
            L_Endabgabe.crc2.fill();
            L_Endabgabe.crc2.lineWidth = this.highlighted ? 2 : 1;
            L_Endabgabe.crc2.strokeStyle = "black";
            L_Endabgabe.crc2.stroke();
            L_Endabgabe.crc2.textAlign = "center";
            L_Endabgabe.crc2.textBaseline = "middle";
            L_Endabgabe.crc2.fillStyle = "white"; //<======= here
            L_Endabgabe.crc2.fillText(this.tricotNumber.toString(), this.position.X, this.position.Y);
            L_Endabgabe.crc2.restore();
        }
        // Wenn Player geklickt wurde:
        isClicked(_clickPosition) {
            let difference = new L_Endabgabe.Vector(_clickPosition.X - this.position.X, _clickPosition.Y - this.position.Y);
            return (difference.length < this.radius);
        }
    }
    L_Endabgabe.Player = Player;
})(L_Endabgabe || (L_Endabgabe = {}));
//# sourceMappingURL=player.js.map