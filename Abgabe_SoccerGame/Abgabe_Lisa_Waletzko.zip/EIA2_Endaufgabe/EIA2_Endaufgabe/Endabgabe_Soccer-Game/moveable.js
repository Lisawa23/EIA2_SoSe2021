"use strict";
var L_Endabgabe;
(function (L_Endabgabe) {
    /**
     * super class to handle movable objects
     */
    class Movable {
        constructor(_position) {
            this.position = _position;
            this.speed = 1;
            this.speedLevel = 1;
            this.slowDown = false;
            this.radius = 2 * L_Endabgabe.scale;
        }
        move(_target) {
            let diffVector = new L_Endabgabe.Vector(_target.X - this.position.X, _target.Y - this.position.Y);
            let vectorLength = Math.sqrt(Math.pow(diffVector.X, 2) + Math.pow(diffVector.Y, 2));
            if (vectorLength === 0) {
                return;
            }
            let speedLevel = this.speedLevel * (this.speed / 100);
            let speed = this.slowDown ? speedLevel * (vectorLength / 100) : speedLevel;
            let scaleFactor = speed / vectorLength;
            diffVector.scale(scaleFactor);
            this.position.add(diffVector);
        }
    }
    L_Endabgabe.Movable = Movable;
})(L_Endabgabe || (L_Endabgabe = {}));
//# sourceMappingURL=moveable.js.map