"use strict";
var L_Endabgabe;
(function (L_Endabgabe) {
    /**
     * super class to handle movable objects
     */
    class Movable {
        constructor(_position) {
            this.position = _position;
            this.speed = 1;
            this.speedLevel = 1;
            this.slowDown = false;
            this.radius = 2 * L_Endabgabe.scale;
        }
        /**
         * moves object to target
         */
        move(_target) {
            // calc diff vector
            let diffVectr = new L_Endabgabe.Vector(_target.X - this.position.X, _target.Y - this.position.Y);
            // calc length of diff vector and return if zero
            let vectorLength = Math.sqrt(Math.pow(diffVectr.X, 2) + Math.pow(diffVectr.Y, 2));
            if (vectorLength === 0) {
                return;
            }
            // calc speed by movable properties
            let speedLevel = this.speedLevel * (this.speed / 100);
            // apply slow down if activated (Ball)
            let speed = this.slowDown ? speedLevel * (vectorLength / 100) : speedLevel;
            // calc scaling
            let scaleFactor = speed / vectorLength;
            // apply scaling to diff
            diffVectr.scale(scaleFactor);
            // add diff to current pos
            this.position.add(diffVectr);
        }
    }
    L_Endabgabe.Movable = Movable;
})(L_Endabgabe || (L_Endabgabe = {}));
//# sourceMappingURL=moveable.js.map