namespace L_Endabgabe {
    /**
     * class to handle player
     */
    export class Player extends Movable {

         // action radius
        public actionRadius: number;
        
        // speed 1 to 99
        public speed: number = 80; 
        
        // tricot number
        public tricotNumber: number;

        // team number
        public team: string; 
        
        // color
        public color: string;

        // precision1 to 99
        public precision: number;
        // shot power
        public shotPower: number;
        
     
        // origin of the player
        public origin: Vector = new Vector(0, 0);  
        
        // whether the player is highlighted or not
        public highlighted: boolean = true;
        // whether the player is displayed on the field or on substitution
        public active: boolean;
        // default speed level which scales with speed
        protected speedLevel: number = 2;
  
          
  
        constructor(_position: Vector, _shotPower: number, _precision: number, _speed: number, _color: string, _team: string, _trikotNumer: number, _actionRadius: number) {
            super(new Vector(_position.X, _position.Y));
            this.shotPower = _shotPower;
            this.precision = _precision;
            this.speed = _speed;
            this.color = _color;
            this.team = _team;
            this.active = true;
            this.tricotNumber = _trikotNumer;
            this.actionRadius = _actionRadius * scale;
            this.origin = new Vector(_position.X, _position.Y);
        }


        public draw(): void {
            crc2.save();

            // draw player center
            crc2.beginPath();
            crc2.arc(this.position.X, this.position.Y, this.highlighted ? this.radius * 1.5 : this.radius, 0, 2 * Math.PI, false);
            crc2.fillStyle = this.color;
            crc2.fill();
            crc2.lineWidth = this.highlighted ? 2 : 1;
            crc2.strokeStyle = "black";
            crc2.stroke(); 
            crc2.textAlign = "center";
            crc2.textBaseline = "middle";
            crc2.fillStyle = "white";  //<======= here
            crc2.fillText(this.tricotNumber.toString(), this.position.X, this.position.Y);

            crc2.restore();
        }

        // Wenn Player geklickt wurde:
        public isClicked(_clickPosition: Vector): Boolean {
            let difference: Vector = new Vector(_clickPosition.X - this.position.X, _clickPosition.Y - this.position.Y);
            return (difference.length < this.radius);
        }

    }
}
